using System;

class PongGame 
{
    static void Main () 
    {
        int x=0;
        int y=0;
        Console.Clear();
        while(true) 
        {
            Console.SetCursorPosition(x, y);
            Console.Write("*");
            x = x + 1;
            y = y + 1;
            System.Threading.Thread.Sleep(500);
        }
    }
}
