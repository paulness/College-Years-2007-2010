using System;

class PongGame 
{
    static void Main () 
    {
        Console.Clear();
        Console.SetCursorPosition(20, 5);
        Console.Write("*");
    }
}
