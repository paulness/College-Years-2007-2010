using System;

class PongGame 
{
    static void Main () 
    {
        int x=0;
        int y=0;
        int xSpeed = 1;
        int ySpeed = 1;
        Console.Clear();
        while(true) {
            Console.SetCursorPosition(x, y);
            Console.Write(" ");
            x = x + xSpeed;
            y = y + ySpeed;
            Console.SetCursorPosition(x, y);
            Console.Write("*");
            System.Threading.Thread.Sleep(500);
        }
    }
}
