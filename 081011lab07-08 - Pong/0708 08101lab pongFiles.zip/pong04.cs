using System;

class PongGame 
{
    static void Main () 
    {
        int x=0;
        int y=0;
        int xSpeed = 1;
        int ySpeed = 1;
        bool gameRunning = true;
        Console.Clear();
        while(gameRunning) {
            // Erase the old game elements
            Console.SetCursorPosition(x, y);
            Console.Write(" ");
            x = x + xSpeed;
            y = y + ySpeed;

            // Get the player move
            if (Console.KeyAvailable)
            {
                ConsoleKeyInfo keyInfo =
                    Console.ReadKey(true);
                switch (keyInfo.Key)
                {
                  case ConsoleKey.Escape:
                  gameRunning = false;
                  break;
                }
            }

            // Draw the new game elements
            Console.SetCursorPosition(x, y);
            Console.Write("*");
            if ( ( x == 79 ) || ( x == 0 ) )
            {
                xSpeed = xSpeed * -1;   
            }

            System.Threading.Thread.Sleep(100);
        }
    }
}
